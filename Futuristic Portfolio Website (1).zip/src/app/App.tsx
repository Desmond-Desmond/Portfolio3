import { useState, useEffect } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { CaseStudiesSection } from './components/CaseStudiesSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { WhyHireMeSection } from './components/WhyHireMeSection';
import { FooterSection } from './components/FooterSection';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'case-studies', 'testimonials', 'why-hire-me'];
      const scrollPosition = window.scrollY + 100;

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <ThemeProvider>
      <div className="size-full bg-white dark:bg-gray-900">
        <Navigation activeSection={activeSection} />
        <HeroSection />
        <AboutSection />
        <CaseStudiesSection />
        <TestimonialsSection />
        <WhyHireMeSection />
        <FooterSection />
      </div>
    </ThemeProvider>
  );
}