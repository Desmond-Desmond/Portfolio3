import { motion } from 'motion/react';
import { Mail, Linkedin, Github, Twitter, FileText, Phone } from 'lucide-react';

export function FooterSection() {
  const socialLinks = [
    { icon: Linkedin, label: "LinkedIn", href: "#" },
    { icon: Twitter, label: "Twitter", href: "#" },
    { icon: Github, label: "GitHub", href: "#" },
    { icon: FileText, label: "Resume", href: "#" },
  ];

  return (
    <footer id="contact" className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 dark:from-gray-900 dark:via-gray-800 dark:to-black text-white py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Let&apos;s Work Together
          </h2>
          <p className="text-xl text-blue-200 dark:text-gray-400 max-w-2xl mx-auto mb-8">
            I am available for freelance projects, remote positions, and design consultations.
          </p>
          <motion.a
            href="mailto:ezikedesmond02@gmail.com"
            className="inline-flex items-center gap-3 px-10 py-4 bg-gradient-to-r from-amber-500 to-amber-600 dark:from-amber-600 dark:to-amber-700 text-white rounded-full font-semibold hover:shadow-2xl transition-all text-lg"
            whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(217, 119, 6, 0.4)" }}
            whileTap={{ scale: 0.95 }}
          >
            <Mail size={24} />
            Get In Touch
          </motion.a>
        </motion.div>

        <div className="border-t border-blue-700 dark:border-gray-700 pt-12">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                Desmond Ezike
              </h3>
              <p className="text-blue-200 dark:text-gray-400 leading-relaxed">
                Creative and detail-oriented designer specializing in UI/UX, web design, and brand identity systems.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <h4 className="font-semibold mb-4 text-lg text-amber-400">Quick Links</h4>
              <ul className="space-y-3">
                {['Home', 'About', 'Work', 'Testimonials', 'Why Me'].map((item, index) => (
                  <motion.li 
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <motion.button
                      onClick={() => {
                        const id = item.toLowerCase() === 'work' ? 'case-studies' : 
                                   item.toLowerCase() === 'why me' ? 'why-hire-me' :
                                   item.toLowerCase();
                        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-blue-200 dark:text-gray-400 hover:text-amber-400 transition-colors"
                      whileHover={{ x: 5 }}
                    >
                      {item}
                    </motion.button>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h4 className="font-semibold mb-4 text-lg text-amber-400">Connect</h4>
              <div className="flex gap-4 mb-6">
                {socialLinks.map((social, index) => {
                  const Icon = social.icon;
                  return (
                    <motion.a
                      key={index}
                      href={social.href}
                      className="w-12 h-12 bg-blue-800 dark:bg-gray-700 rounded-full flex items-center justify-center hover:bg-amber-600 transition-colors"
                      aria-label={social.label}
                      whileHover={{ scale: 1.2, rotate: 360 }}
                      whileTap={{ scale: 0.9 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Icon size={20} />
                    </motion.a>
                  );
                })}
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-blue-300 dark:text-gray-500 text-sm mb-2">Email</p>
                  <motion.a
                    href="mailto:ezikedesmond02@gmail.com"
                    className="text-white hover:text-amber-400 transition-colors"
                    whileHover={{ x: 5 }}
                  >
                    ezikedesmond02@gmail.com
                  </motion.a>
                </div>
                <div>
                  <p className="text-blue-300 dark:text-gray-500 text-sm mb-2">Phone</p>
                  <motion.a
                    href="tel:07072512862"
                    className="text-white hover:text-amber-400 transition-colors flex items-center gap-2"
                    whileHover={{ x: 5 }}
                  >
                    <Phone size={16} />
                    07072512862
                  </motion.a>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div 
            className="border-t border-blue-700 dark:border-gray-700 pt-8 text-center text-blue-300 dark:text-gray-400 text-sm"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <p>
              &copy; {new Date().getFullYear()} Desmond Ezike. All rights reserved.
              Designed with strategy and intention.
            </p>
          </motion.div>
        </div>
      </div>
    </footer>
  );
}