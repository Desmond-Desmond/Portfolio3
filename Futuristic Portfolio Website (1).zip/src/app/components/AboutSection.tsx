import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export function AboutSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section id="about" className="py-24 bg-white dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 dark:text-white mb-4">
            About Me
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-600 to-amber-700 mx-auto"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              I am <span className="font-semibold text-blue-900 dark:text-amber-400">Desmond Ezike</span>, a results-driven Web & Graphic Designer specializing in UI/UX design, brand identity, and high-converting digital experiences.
            </p>
            
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              I do not just make things look good — I design with intention.
            </p>
            
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              Every layout, color choice, and interaction is guided by strategy, user psychology, and business goals. My focus is simple: create digital experiences that are visually stunning and strategically effective.
            </p>
            
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
              I have worked on website designs, landing pages, brand systems, and marketing visuals that help businesses stand out in competitive markets. I understand how users think, how brands communicate, and how design influences decisions.
            </p>
          </motion.div>

          <motion.div 
            className="space-y-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.div 
              className="bg-blue-50 dark:bg-gray-800 p-6 rounded-2xl border border-blue-100 dark:border-gray-700"
              variants={itemVariants}
              whileHover={{ scale: 1.02, boxShadow: "0 10px 30px rgba(30, 58, 138, 0.1)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <h3 className="text-xl font-semibold text-blue-900 dark:text-amber-400 mb-4">
                As a remote designer, I bring:
              </h3>
              <ul className="space-y-3">
                {[
                  'Clear communication',
                  'Structured workflow',
                  'Strong attention to detail',
                  'Fast turnaround without sacrificing quality',
                  'Seamless collaboration with developers and marketing teams',
                ].map((item, index) => (
                  <motion.li 
                    key={index} 
                    className="flex items-start gap-3"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <CheckCircle2 size={20} className="text-amber-600 dark:text-amber-500 mt-1 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{item}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div 
              className="bg-blue-50 dark:bg-gray-800 p-6 rounded-2xl border border-blue-100 dark:border-gray-700"
              variants={itemVariants}
              whileHover={{ scale: 1.02, boxShadow: "0 10px 30px rgba(30, 58, 138, 0.1)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <h3 className="text-xl font-semibold text-blue-900 dark:text-amber-400 mb-4">
                Tools & Skills
              </h3>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                My tools of choice include <span className="font-medium text-blue-900 dark:text-amber-400">Figma, Adobe Photoshop, Illustrator, Adobe XD</span>, and modern web design platforms. I design scalable systems — not just single pages.
              </p>
            </motion.div>

            <motion.div 
              className="bg-gradient-to-br from-blue-900 to-blue-800 dark:from-amber-600 dark:to-amber-700 text-white p-6 rounded-2xl shadow-xl"
              variants={itemVariants}
              whileHover={{ scale: 1.02, boxShadow: "0 20px 40px rgba(30, 58, 138, 0.3)" }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <p className="text-lg leading-relaxed">
                If you are looking for someone who blends creativity with strategy, precision with innovation, and aesthetics with performance — <span className="font-semibold text-amber-300 dark:text-white">we will work well together.</span>
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}