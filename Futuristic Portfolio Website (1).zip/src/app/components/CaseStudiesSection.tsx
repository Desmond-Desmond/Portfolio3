import { motion } from 'motion/react';
import { ArrowRight, Target, Zap, TrendingUp } from 'lucide-react';

const caseStudies = [
  {
    id: 1,
    icon: Target,
    title: 'SaaS Landing Page Redesign',
    problem: 'The client had a cluttered website with low conversion rates and unclear messaging.',
    solution: 'I redesigned the landing page with a clean layout, stronger typography hierarchy, improved CTA placement, and a modern UI system.',
    results: [
      'Improved user engagement',
      'Increased sign-up conversions',
      'Stronger brand credibility',
    ],
    tools: 'Figma, Photoshop',
    color: 'from-blue-600 to-blue-800',
  },
  {
    id: 2,
    icon: Zap,
    title: 'Brand Identity for Fashion Startup',
    problem: 'The brand lacked visual consistency and market positioning.',
    solution: 'Created a full identity system including logo, color palette, typography system, social media templates, and packaging mockups.',
    results: [
      'Cohesive premium look',
      'Increased social media engagement',
      'Stronger brand recognition',
    ],
    tools: 'Illustrator, Photoshop',
    color: 'from-amber-500 to-amber-700',
  },
  {
    id: 3,
    icon: TrendingUp,
    title: 'Mobile App UI Design',
    problem: 'The app interface was outdated and difficult to navigate.',
    solution: 'Designed a modern, intuitive UI with simplified navigation, improved visual hierarchy, and user-focused interaction patterns.',
    results: [
      'Better user experience',
      'Improved app usability',
      'Positive beta user feedback',
    ],
    tools: 'Figma',
    color: 'from-blue-700 to-indigo-900',
  },
];

export function CaseStudiesSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="case-studies" className="py-24 bg-gradient-to-br from-blue-50 to-white dark:from-gray-800 dark:to-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 dark:text-white mb-4">
            Case Studies
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-600 to-amber-700 mx-auto mb-4"></div>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            Real projects. Real results. Strategic design that drives business growth.
          </p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {caseStudies.map((study, index) => {
            const Icon = study.icon;
            return (
              <motion.div
                key={study.id}
                variants={cardVariants}
                whileHover={{ 
                  y: -10, 
                  boxShadow: "0 20px 40px rgba(30, 58, 138, 0.2)" 
                }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg"
              >
                <motion.div 
                  className={`bg-gradient-to-br ${study.color} p-8 text-white`}
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div
                    initial={{ rotate: 0 }}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon size={40} className="mb-4" />
                  </motion.div>
                  <h3 className="text-2xl font-bold mb-2">{study.title}</h3>
                </motion.div>

                <div className="p-6 space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold text-amber-600 dark:text-amber-500 mb-2 uppercase tracking-wide">
                      Problem
                    </h4>
                    <p className="text-gray-700 dark:text-gray-300">{study.problem}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-amber-600 dark:text-amber-500 mb-2 uppercase tracking-wide">
                      Solution
                    </h4>
                    <p className="text-gray-700 dark:text-gray-300">{study.solution}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-amber-600 dark:text-amber-500 mb-3 uppercase tracking-wide">
                      Results
                    </h4>
                    <ul className="space-y-2">
                      {study.results.map((result, idx) => (
                        <motion.li 
                          key={idx} 
                          className="flex items-start gap-2"
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: idx * 0.1 }}
                        >
                          <ArrowRight size={16} className="text-blue-900 dark:text-amber-500 mt-1 flex-shrink-0" />
                          <span className="text-gray-700 dark:text-gray-300">{result}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      <span className="font-semibold text-blue-900 dark:text-amber-400">Tools:</span> {study.tools}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}