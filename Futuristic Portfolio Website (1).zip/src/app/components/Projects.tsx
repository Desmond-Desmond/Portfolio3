import { motion } from 'motion/react';
import { useState } from 'react';
import { ExternalLink, Filter } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: 'TechFlow SaaS Platform',
    category: 'Web',
    description:
      'Modern SaaS dashboard with real-time analytics and intuitive UX',
    technologies: ['React', 'TypeScript', 'Tailwind', 'Node.js'],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
  },
  {
    id: 2,
    title: 'Luxe Brand Identity',
    category: 'Branding',
    description: 'Complete brand overhaul for luxury fashion retailer',
    technologies: ['Figma', 'Adobe Suite', 'Brand Strategy'],
    image: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=800&q=80',
  },
  {
    id: 3,
    title: 'FinanceHub Mobile App',
    category: 'UI Design',
    description: 'Intuitive mobile banking experience with dark mode',
    technologies: ['Figma', 'UI/UX', 'Prototyping'],
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&q=80',
  },
  {
    id: 4,
    title: 'E-Commerce Revolution',
    category: 'Web',
    description: 'High-converting online store with seamless checkout',
    technologies: ['React', 'Shopify', 'Motion', 'Stripe'],
    image: 'https://images.unsplash.com/photo-1557821552-17105176677c?w=800&q=80',
  },
  {
    id: 5,
    title: 'Creative Studio Rebrand',
    category: 'Branding',
    description: 'Bold visual identity for digital creative agency',
    technologies: ['Illustrator', 'After Effects', 'Brand Guidelines'],
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80',
  },
  {
    id: 6,
    title: 'Medical Portal Dashboard',
    category: 'UI Design',
    description: 'Healthcare management system with data visualization',
    technologies: ['Figma', 'Design System', 'Accessibility'],
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80',
  },
];

const categories = ['All', 'Web', 'Branding', 'UI Design'];

export function Projects() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProjects =
    activeCategory === 'All'
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  return (
    <section id="projects" className="relative py-32 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <motion.span
              className="inline-block text-cyan-400 text-sm tracking-widest mb-4"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              PORTFOLIO
            </motion.span>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Selected
              <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
                {' '}
                Work
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              A showcase of projects that blend strategic thinking with stunning
              design execution
            </p>
          </div>

          {/* Filter */}
          <motion.div
            className="flex flex-wrap justify-center gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Filter className="w-5 h-5 text-cyan-400 self-center" />
            {categories.map((category) => (
              <motion.button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2 rounded-full font-medium transition-all ${
                  activeCategory === category
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                    : 'bg-gray-900/50 text-gray-400 hover:text-white border border-cyan-500/20'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category}
              </motion.button>
            ))}
          </motion.div>

          {/* Projects Grid */}
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            layout
          >
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                className="group relative rounded-2xl overflow-hidden bg-gray-900/50 backdrop-blur-sm border border-cyan-500/10 hover:border-cyan-500/30 transition-all"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                layout
              >
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <motion.img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover"
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />

                  {/* Hover overlay */}
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                  >
                    <motion.button
                      className="px-6 py-3 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium flex items-center gap-2"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      View Case Study
                      <ExternalLink className="w-4 h-4" />
                    </motion.button>
                  </motion.div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs text-cyan-400 font-medium tracking-wider">
                      {project.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-400 text-sm mb-4">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="text-xs px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Glow effect */}
                <motion.div
                  className="absolute -inset-1 bg-gradient-to-r from-cyan-500/50 to-purple-600/50 rounded-2xl blur opacity-0 group-hover:opacity-50 transition-opacity -z-10"
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 0.5 }}
                />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
