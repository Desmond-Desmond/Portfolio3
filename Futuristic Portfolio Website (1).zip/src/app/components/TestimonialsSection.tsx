import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Sarah M.',
    role: 'Marketing Director',
    quote: 'Desmond completely transformed our website. The new design feels premium, modern, and user-friendly. Our bounce rate dropped significantly within weeks. He understands both aesthetics and user behavior.',
    rating: 5,
  },
  {
    id: 2,
    name: 'Daniel R.',
    role: 'Product Manager',
    quote: 'Working with Desmond remotely was seamless. He communicates clearly, meets deadlines, and delivers beyond expectations. His UI design elevated our product to a new level.',
    rating: 5,
  },
  {
    id: 3,
    name: 'Anita K.',
    role: 'Brand Strategist',
    quote: 'We needed a brand identity that felt bold and modern — Desmond delivered exactly that. From logo to social media visuals, everything was cohesive and impactful.',
    rating: 5,
  },
];

export function TestimonialsSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="testimonials" className="py-24 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 dark:text-white mb-4">
            Client Testimonials
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-600 to-amber-700 mx-auto mb-4"></div>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            Do not just take my word for it. Here is what clients say about working with me.
          </p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              variants={cardVariants}
              whileHover={{ 
                y: -10, 
                boxShadow: "0 20px 40px rgba(30, 58, 138, 0.15)" 
              }}
              transition={{ type: "spring", stiffness: 300 }}
              className="bg-gradient-to-br from-blue-50 to-white dark:from-gray-800 dark:to-gray-800 rounded-2xl p-8 relative border border-blue-100 dark:border-gray-700"
            >
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                whileInView={{ scale: 1, rotate: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, type: "spring" }}
              >
                <Quote size={40} className="text-amber-600/20 dark:text-amber-500/20 absolute top-6 right-6" />
              </motion.div>
              
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 + (i * 0.1) }}
                  >
                    <Star size={20} className="fill-amber-500 text-amber-500" />
                  </motion.div>
                ))}
              </div>

              <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6 relative z-10">
                &quot;{testimonial.quote}&quot;
              </p>

              <div className="flex items-center gap-4">
                <motion.div 
                  className="w-12 h-12 bg-gradient-to-br from-blue-900 to-blue-700 dark:from-amber-600 dark:to-amber-700 rounded-full flex items-center justify-center text-white font-semibold"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  {testimonial.name.charAt(0)}
                </motion.div>
                <div>
                  <p className="font-semibold text-blue-900 dark:text-amber-400">{testimonial.name}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}