import { motion } from 'motion/react';
import { TrendingUp, Zap, Target, MessageCircle } from 'lucide-react';

const reasons = [
  {
    icon: TrendingUp,
    title: 'Results-Driven Design',
    description:
      'Every design decision is backed by data and focused on achieving your business goals and maximizing conversions.',
  },
  {
    icon: Zap,
    title: 'Fast Turnaround',
    description:
      'Efficient workflows and streamlined processes ensure timely delivery without compromising on quality or attention to detail.',
  },
  {
    icon: Target,
    title: 'Detail-Oriented Execution',
    description:
      'Obsessive focus on every pixel, interaction, and user touchpoint to create flawless experiences that exceed expectations.',
  },
  {
    icon: MessageCircle,
    title: 'Clear Communication',
    description:
      'Transparent updates, collaborative approach, and responsive feedback loops keep you informed throughout the entire process.',
  },
];

export function WhyHireMe() {
  return (
    <section id="why-hire-me" className="relative py-32 px-6 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <motion.div
          className="absolute top-1/2 left-1/2 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            x: [-100, 100, -100],
            y: [-50, 50, -50],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <motion.span
              className="inline-block text-cyan-400 text-sm tracking-widest mb-4"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              WHY CHOOSE ME
            </motion.span>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              What Sets Me
              <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
                {' '}
                Apart
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              More than just a designer—a strategic partner committed to your
              success
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {reasons.map((reason, index) => (
              <motion.div
                key={reason.title}
                className="group relative"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
              >
                <motion.div
                  className="relative p-8 rounded-2xl bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-xl border border-cyan-500/20 hover:border-cyan-500/40 transition-all"
                  whileHover={{ scale: 1.02, y: -5 }}
                >
                  {/* Icon with animated background */}
                  <motion.div
                    className="relative inline-block mb-6"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: 'spring', stiffness: 300 }}
                  >
                    <div className="relative z-10 p-4 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg">
                      <reason.icon className="w-8 h-8 text-white" />
                    </div>
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl blur-xl opacity-50"
                      animate={{
                        scale: [1, 1.2, 1],
                        opacity: [0.5, 0.8, 0.5],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: 'easeInOut',
                      }}
                    />
                  </motion.div>

                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors">
                    {reason.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {reason.description}
                  </p>

                  {/* Decorative corner accent */}
                  <motion.div
                    className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-cyan-500/20 to-transparent rounded-bl-3xl"
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                  />

                  {/* Hover glow */}
                  <motion.div
                    className="absolute -inset-1 bg-gradient-to-r from-cyan-500/50 to-purple-600/50 rounded-2xl blur opacity-0 group-hover:opacity-50 transition-opacity -z-10"
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 0.5 }}
                  />
                </motion.div>
              </motion.div>
            ))}
          </div>

          {/* CTA Banner */}
          <motion.div
            className="mt-16 relative p-12 rounded-3xl bg-gradient-to-br from-cyan-500/10 to-purple-600/10 border border-cyan-500/30 backdrop-blur-xl overflow-hidden"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
          >
            {/* Animated background */}
            <motion.div
              className="absolute inset-0 opacity-30"
              style={{
                background:
                  'linear-gradient(45deg, transparent 30%, rgba(34, 211, 238, 0.1) 50%, transparent 70%)',
                backgroundSize: '200% 200%',
              }}
              animate={{
                backgroundPosition: ['0% 0%', '100% 100%'],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                repeatType: 'reverse',
              }}
            />

            <div className="relative z-10 text-center">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Ready to Start Your Project?
              </h3>
              <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
                Let's collaborate to create something extraordinary that drives
                real results for your business
              </p>
              <motion.button
                onClick={() => {
                  const element = document.getElementById('contact');
                  element?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-8 py-4 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Let's Talk
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
