import { motion } from 'motion/react';
import { Code2, Palette, Layers, Zap, Target, Lightbulb } from 'lucide-react';

const tools = [
  'Figma',
  'Adobe Suite',
  'HTML',
  'CSS',
  'JavaScript',
  'React',
  'WordPress',
  'Tailwind',
];

const qualities = [
  { icon: Lightbulb, label: 'Creativity' },
  { icon: Target, label: 'Strategy' },
  { icon: Zap, label: 'Attention to Detail' },
  { icon: Code2, label: 'Problem-Solving' },
  { icon: Layers, label: 'Scalable Code' },
  { icon: Palette, label: 'Design Systems' },
];

export function About() {
  return (
    <section id="about" className="relative py-32 px-6 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-16">
            <motion.span
              className="inline-block text-cyan-400 text-sm tracking-widest mb-4"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              WHO I AM
            </motion.span>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Crafting Excellence
              <br />
              <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
                Through Vision
              </span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <motion.div
              className="relative group"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative z-10 p-8 rounded-3xl bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-xl border border-cyan-500/20">
                <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/50 to-purple-600/50 rounded-3xl blur opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Desmond Ezike
                  </h3>
                  <p className="text-gray-300 leading-relaxed mb-6">
                    I'm a visionary designer and developer who transforms complex
                    challenges into elegant, high-converting digital solutions.
                    With a strategic approach to every project, I combine
                    aesthetic brilliance with technical precision to create
                    experiences that don't just look incredible—they deliver
                    measurable results.
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    My work is driven by three principles: intentional design,
                    scalable architecture, and obsessive attention to detail.
                    Every pixel, every interaction, every line of code serves a
                    purpose—to elevate brands and captivate audiences.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div
              className="grid grid-cols-2 gap-4"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              {qualities.map((quality, index) => (
                <motion.div
                  key={quality.label}
                  className="p-6 rounded-2xl bg-gradient-to-br from-gray-900/50 to-black/50 backdrop-blur-sm border border-cyan-500/10 hover:border-cyan-500/30 transition-all group"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                >
                  <quality.icon className="w-8 h-8 text-cyan-400 mb-3 group-hover:scale-110 transition-transform" />
                  <p className="text-white font-medium">{quality.label}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Tools */}
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-bold text-white mb-8">
              Technology Stack
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              {tools.map((tool, index) => (
                <motion.div
                  key={tool}
                  className="px-6 py-3 rounded-full bg-gradient-to-r from-cyan-500/10 to-purple-600/10 border border-cyan-500/30 backdrop-blur-sm"
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{
                    scale: 1.1,
                    backgroundColor: 'rgba(34, 211, 238, 0.1)',
                  }}
                >
                  <span className="text-cyan-400 font-medium">{tool}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
