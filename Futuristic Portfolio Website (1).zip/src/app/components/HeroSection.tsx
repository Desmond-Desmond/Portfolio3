import { motion } from 'motion/react';
import { ArrowDown } from 'lucide-react';

export function HeroSection() {
  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-amber-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 pt-20">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div 
            className="inline-block px-4 py-2 bg-gradient-to-r from-blue-900 to-blue-800 dark:from-amber-600 dark:to-amber-700 text-white rounded-full text-sm mb-6"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            ✨ Premium Portfolio
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-blue-900 dark:text-white mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            Desmond Ezike
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl bg-gradient-to-r from-amber-600 to-amber-700 dark:from-amber-400 dark:to-amber-600 bg-clip-text text-transparent font-semibold mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Web & Graphic Designer
          </motion.p>
          
          <motion.p 
            className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            Specializing in UI/UX design, brand identity, and high-converting digital experiences.
            I design with intention — every pixel serves a purpose.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <motion.button
              onClick={() => document.getElementById('case-studies')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 bg-gradient-to-r from-blue-900 to-blue-800 dark:from-amber-600 dark:to-amber-700 text-white rounded-full hover:shadow-2xl transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              View My Work
            </motion.button>
            <motion.button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 border-2 border-amber-600 dark:border-amber-500 text-amber-700 dark:text-amber-400 rounded-full hover:bg-amber-600 dark:hover:bg-amber-600 hover:text-white transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Get In Touch
            </motion.button>
          </motion.div>
        </motion.div>

        <motion.button
          onClick={scrollToAbout}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-16 text-blue-900 dark:text-amber-400 hover:text-amber-600 dark:hover:text-amber-300 transition-colors"
          whileHover={{ y: 5 }}
        >
          <ArrowDown size={32} className="animate-bounce mx-auto" />
        </motion.button>
      </div>
    </section>
  );
}