import { motion } from 'motion/react';
import { Target, Brain, Layers, Globe, Clock, Heart } from 'lucide-react';

const reasons = [
  {
    icon: Target,
    title: 'I design with strategy, not guesswork',
    description: 'Every decision is backed by research, user psychology, and business goals.',
  },
  {
    icon: Brain,
    title: 'I understand user behavior and conversion psychology',
    description: 'Design that influences decisions and drives measurable results.',
  },
  {
    icon: Layers,
    title: 'I deliver clean, scalable, developer-friendly designs',
    description: 'Systems that are easy to implement and maintain long-term.',
  },
  {
    icon: Globe,
    title: 'I communicate clearly across time zones',
    description: 'Remote collaboration made simple with structured communication.',
  },
  {
    icon: Clock,
    title: 'I respect deadlines and project structure',
    description: 'Organized workflow, transparent progress, on-time delivery.',
  },
  {
    icon: Heart,
    title: 'I care about quality - deeply',
    description: 'Not just completing tasks, but creating work I am proud of.',
  },
];

export function WhyHireMeSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="why-hire-me" className="py-24 bg-gradient-to-br from-blue-50 to-white dark:from-gray-800 dark:to-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 dark:text-white mb-4">
            Why Hire Me?
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-600 to-amber-700 mx-auto mb-4"></div>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            I bring more than design skills - I bring strategic thinking and commitment to excellence.
          </p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={index}
                variants={cardVariants}
                whileHover={{ 
                  y: -10, 
                  boxShadow: "0 20px 40px rgba(30, 58, 138, 0.15)" 
                }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-md border border-blue-100 dark:border-gray-700"
              >
                <motion.div 
                  className="w-14 h-14 bg-gradient-to-br from-blue-900 to-blue-700 dark:from-amber-600 dark:to-amber-700 rounded-xl flex items-center justify-center mb-6"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  <Icon size={28} className="text-white" />
                </motion.div>
                <h3 className="text-xl font-semibold text-blue-900 dark:text-amber-400 mb-3">
                  {reason.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                  {reason.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <motion.div 
            className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 dark:from-amber-600 dark:via-amber-700 dark:to-amber-600 rounded-3xl p-12 text-white shadow-2xl"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
          >
            <motion.h3 
              className="text-3xl font-bold mb-4"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              Ready to elevate your digital presence?
            </motion.h3>
            <motion.p 
              className="text-xl mb-8 text-blue-200 dark:text-amber-100"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
            >
              Let us create something exceptional together.
            </motion.p>
            <motion.button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-10 py-4 bg-gradient-to-r from-amber-500 to-amber-600 dark:from-blue-900 dark:to-blue-800 text-white rounded-full font-semibold hover:shadow-2xl transition-all text-lg"
              whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(217, 119, 6, 0.4)" }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              Start a Project
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}