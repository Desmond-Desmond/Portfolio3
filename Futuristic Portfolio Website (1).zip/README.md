
  # Futuristic Portfolio Website

  This is a code bundle for Futuristic Portfolio Website. The original project is available at https://www.figma.com/design/MbsoEtdvY0wL3nZXMgFpnS/Futuristic-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  